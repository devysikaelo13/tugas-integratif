<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;


class Restclient extends REST_Controller {

    public function index_get(){
        // URL of the REST Server
        $url = "http://127.0.0.1/nanana/app/dashboard/index.php/restserver";

        // Get Data from REST Server
        $response = file_get_contents($url);

        // Handle the respon, e.g. echo
        echo $response;
    }
}