<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Categories extends CI_Controller
{

	public function coffee()
	{
		$data['title'] = 'Coffee';
		$data['coffee'] = $this->model_kategori->coffee()->result();
		$this->load->view('layout/home/header', $data);
		$this->load->view('electronic', $data);
		$this->load->view('layout/home/footer');
	}

	public function noncoffee()
	{
		$data['title'] = 'Non Coffee';
		$data['noncoffee'] = $this->model_kategori->noncoffee()->result();
		$this->load->view('layout/home/header', $data);
		$this->load->view('shirt', $data);
		$this->load->view('layout/home/footer');
	}

	public function jussayuran()
	{
		$data['title'] = 'Jus Sayuran';
		$data['jussayuran'] = $this->model_kategori->jussayuran()->result();
		$this->load->view('layout/home/header', $data);
		$this->load->view('shirt', $data);
		$this->load->view('layout/home/footer');
	}

	public function jusbuah()
	{
		$data['title'] = 'Jus Sayuran';
		$data['jusbuah'] = $this->model_kategori->jusbuah()->result();
		$this->load->view('layout/home/header', $data);
		$this->load->view('shirt', $data);
		$this->load->view('layout/home/footer');
	}
}
