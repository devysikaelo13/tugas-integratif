<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;


class Restserver extends REST_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('Model_produk', 'produk');
    }

    //Mendapatkan data buku
    public function index_get()
 
    {
        $idb = $this->get('id_brg');
 
        if ($idb === null) {
            $idproduk = $this->produk->getproduk($idb);
        } else {
            $idproduk = $this->produk->getproduk($idb);
        }
 
        if ($idproduk) {
            $this->response([
                'status' => true,
                'data' => $idproduk
            ], Rest_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], Rest_Controller::HTTP_NOT_FOUND);
        }
    }
}