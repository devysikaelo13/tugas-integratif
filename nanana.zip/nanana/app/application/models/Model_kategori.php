<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_kategori extends CI_Model
{
	public function coffee()
	{
		return $this->db->get_where('product', array('kategori' => 'Coffee'));
	}

	public function noncoffee()
	{
		return $this->db->get_where('product', array('kategori' => 'Con Coffee'));
	}

	public function jussayuran()
	{
		return $this->db->get_where('product', array('kategori' => 'Jus Sayuran'));
	}

	public function jusbuah()
	{
		return $this->db->get_where('product', array('kategori' => 'Jus Buah'));
	}
}
