<?php
defined('BASEPATH') or exit('No direct script access allowed');
 
class Model_produk extends CI_Model
{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function getproduk($idb)
    {
        if ($idb === null) {
            return $this->db->get('product')->result_array();
        } else {
            return $this->db->get_where('product', ['id_brg' => $idb])->result_array();
        }
    }
}